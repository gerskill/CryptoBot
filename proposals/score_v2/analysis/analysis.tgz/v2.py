import pandas as pd,numpy as np
from sklearn.metrics import roc_auc_score,brier_score_loss
from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression
u=pd.read_pickle('uniq3.pkl'); p=pd.read_pickle('pos2.pkl')
print('corr score_abs vs:',u[['score_alpha_absolute','price_change_5m_at_entry','vol_liq','log_liq','log_hold','log_age','rugcheck_score']].corr(method='spearman').iloc[0].round(2).to_dict())
# share of the score explained
def prep(d):
    d=d.copy(); d['mom']=d.price_change_5m_at_entry.clip(-50,100); d['lvlr']=np.log10((d.volume_1h_at_entry/d.liquidity_at_entry.clip(lower=1)).clip(0.01)); return d
u=prep(u); p=prep(p)
tr=u[u.split=='train']; te=u[u.split=='test']
F=['mom','lvlr']
lr=LogisticRegression(C=1.0).fit(tr[F],tr.win)
print('v2 LR raw coefs',dict(zip(F,lr.coef_[0].round(4))),'intercept',round(lr.intercept_[0],4))
st=lr.decision_function(tr[F]); se=lr.decision_function(te[F])
print('AUC win tr/te',round(roc_auc_score(tr.win,st),3),round(roc_auc_score(te.win,se),3),'| hit10 te',round(roc_auc_score(te.hit10,se),3),'| win_mean(cluster) te',round(roc_auc_score(te.win_mean,se),3))
pr=lr.predict_proba(te[F])[:,1]
print('Brier te',round(brier_score_loss(te.win,pr),4),'base',round(brier_score_loss(te.win,np.full(len(te),tr.win.mean())),4))
iso=IsotonicRegression(out_of_bounds='clip').fit(lr.predict_proba(tr[F])[:,1],tr.win)
print('Brier te iso',round(brier_score_loss(te.win,iso.predict(pr)),4))
# reliability on test
b=pd.qcut(pr,5); print(pd.DataFrame({'pred':pr,'obs':te.win.values}).groupby(b,observed=True).agg(n=('obs','size'),pred=('pred','mean'),obs=('obs','mean')).round(3))
# bootstrap AUC CI on test
rng=np.random.default_rng(0); a=[]
y=te.win.values
for _ in range(2000):
    i=rng.integers(0,len(y),len(y))
    if y[i].min()!=y[i].max(): a.append(roc_auc_score(y[i],se[i]))
print('AUC test 95% CI',np.percentile(a,[2.5,97.5]).round(3))
t50=np.quantile(lr.predict_proba(tr[F])[:,1],0.5); t70=np.quantile(lr.predict_proba(tr[F])[:,1],0.7)
print('seuils proba top50/top30 (train):',round(t50,4),round(t70,4))
pt=p[p.te>=te.te.min()].copy(); pt['pr']=lr.predict_proba(pt[F])[:,1]
def stats(x):
    g=x.pnl_usd[x.pnl_usd>0].sum(); l=-x.pnl_usd[x.pnl_usd<0].sum()
    r=x.net_pct; t=r.mean()/(r.std()/np.sqrt(len(r))) if len(r)>2 else np.nan
    return f"n={len(x)} PF={g/l:.2f} WR={x.win.mean()*100:.0f}% PnL={x.pnl_usd.sum():+.0f}$ moy={r.mean():+.1f}% t={t:.2f}"
for nm,sub in [('tous bras',pt),('baseline',pt[pt.arm=='baseline'])]:
    print(nm); 
    for lab,m in [('tout',sub.pr>=0),('>=top50',sub.pr>=t50),('>=top30',sub.pr>=t70),('<top50',sub.pr<t50)]:
        print('   ',lab,stats(sub[m]))
# halves of test for baseline
bt=pt[pt.arm=='baseline'].sort_values('te'); h=len(bt)//2
for nm,x in [('1ere moitie',bt[:h]),('2e moitie',bt[h:])]:
    print('baseline test',nm,'tout:',stats(x),'| top50:',stats(x[x.pr>=t50]))
# simple rule: mom5m < 15
for thr in [0,15]:
    for nm,sub in [('tous bras',pt),('baseline',pt[pt.arm=='baseline'])]:
        print(f'regle mom5m<{thr}',nm,stats(sub[sub.price_change_5m_at_entry<thr]))
# same on train period baseline for sanity
ptr=p[(p.te<te.te.min())&(p.arm=='baseline')].copy(); ptr['pr']=lr.predict_proba(ptr[F])[:,1]
print('baseline TRAIN tout',stats(ptr),'| top50',stats(ptr[ptr.pr>=t50]))

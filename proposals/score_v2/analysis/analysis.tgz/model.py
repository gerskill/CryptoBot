import json,pandas as pd,numpy as np
from sklearn.metrics import roc_auc_score,brier_score_loss
from sklearn.linear_model import LogisticRegression
from sklearn.isotonic import IsotonicRegression
u=pd.read_pickle('uniq.pkl'); p=pd.read_pickle('pos2.pkl')
tr=u[u.split=='train']; te=u[u.split=='test']
# --- calibration du score actuel
print('== calibration score_alpha_absolute (clusters uniques)')
for nm,d in [('all',u)]:
    b=pd.cut(d.score_alpha_absolute,[0,55,60,65,70,75,80,85,90,101],right=False)
    g=d.groupby(b,observed=True).agg(n=('hit10','size'),hit10=('hit10','mean'),wr=('win','mean'),pnl=('net_pct','mean'))
    print(g.round(3))
dd=u.dropna(subset=['score_alpha_absolute'])
for tgt in ['hit10','win']:
    print(tgt,'Brier score/100:',round(brier_score_loss(dd[tgt],dd.score_alpha_absolute/100),3),'Brier base rate:',round(brier_score_loss(dd[tgt],np.full(len(dd),dd[tgt].mean())),3))
# per arm calib (positions, not dedup) baseline
b=p[p.arm=='baseline']; bb=pd.cut(b.score_alpha_absolute,[0,60,75,85,101],right=False)
print('baseline arm positions by score:'); print(b.groupby(bb,observed=True).agg(n=('win','size'),wr=('win','mean'),hit10=('hit10','mean'),pnl=('net_pct','mean')).round(3))
# --- economie join (round trip at entry)
e=pd.DataFrame([json.loads(l) for l in open('economie.jsonl')]); e['ets']=pd.to_datetime(e.ts,unit='s',utc=True).astype('datetime64[us, UTC]')
e=e[e.passed==True]
pp=p.copy(); pp['te']=pp.te.astype('datetime64[us, UTC]'); pp=pp.sort_values('te')
e=e.sort_values('ets')
j=pd.merge_asof(pp,e[['ets','arm','token','round_trip_pct']].rename(columns={'token':'token_address','round_trip_pct':'rt_entry'}),left_on='te',right_on='ets',by=['arm','token_address'],tolerance=pd.Timedelta('30s'),direction='nearest')
jj=j.dropna(subset=['rt_entry'])
print('== round_trip a l entree (funnel economie), positions jointes:',len(jj),'periode',jj.te.min(),jj.te.max())
uj=jj.groupby('cluster').first()
print('clusters',len(uj),'AUC hit10',round(roc_auc_score(uj.hit10,-uj.rt_entry),3),'AUC win',round(roc_auc_score(uj.win,-uj.rt_entry),3))
q=pd.qcut(uj.rt_entry,4); print(uj.groupby(q,observed=True).agg(n=('win','size'),wr=('win','mean'),hit10=('hit10','mean'),pnl=('net_pct','mean')).round(3))
print('filtre rt<=5: ',uj[uj.rt_entry<=5].net_pct.mean().round(2),'vs >5:',uj[uj.rt_entry>5].net_pct.mean().round(2), (uj.rt_entry>5).sum())
# --- modele v2
feats=['neg_mom','log_liq','log_age','log_hold','log_vlr']
for d in (u,):
    d['neg_mom']=-d.price_change_5m_at_entry.clip(-50,100); d['log_vlr']=np.log10(d.vol_liq.clip(0.01))
tr=u[u.split=='train']; te=u[u.split=='test']
mu=tr[feats].mean(); sd=tr[feats].std()
def Z(d): return (d[feats]-mu)/sd
for tgt in ['hit10','win']:
    lr=LogisticRegression(C=0.1).fit(Z(tr),tr[tgt])
    s_tr=lr.decision_function(Z(tr)); s_te=lr.decision_function(Z(te))
    iso=IsotonicRegression(out_of_bounds='clip',y_min=0.01,y_max=0.99).fit(s_tr,tr[tgt])
    pr_te=lr.predict_proba(Z(te))[:,1]
    print(f'== LR {tgt}: coefs',dict(zip(feats,lr.coef_[0].round(3))),'int',lr.intercept_.round(3))
    print('  AUC train',round(roc_auc_score(tr[tgt],s_tr),3),'AUC test',round(roc_auc_score(te[tgt],s_te),3),
      'Brier test LR',round(brier_score_loss(te[tgt],pr_te),4),'iso',round(brier_score_loss(te[tgt],iso.predict(s_te)),4),'base',round(brier_score_loss(te[tgt],np.full(len(te),tr[tgt].mean())),4))
    # stability: test halves
    h=len(te)//2
    print('  AUC test 1ere moitie',round(roc_auc_score(te[tgt][:h],s_te[:h]),3),'2e moitie',round(roc_auc_score(te[tgt][h:],s_te[h:]),3))
    u[f's_{tgt}']=lr.decision_function(Z(u))
    thr50=np.quantile(s_tr,0.5); thr70=np.quantile(s_tr,0.7)
    # PF sim on test positions (all arms, and baseline only)
    pt=p[p.te>=te.te.min()].copy()
    pt['neg_mom']=-pt.price_change_5m_at_entry.clip(-50,100); pt['log_vlr']=np.log10(pt.vol_liq.clip(0.01))
    pt['s']=lr.decision_function(Z(pt))
    def pf(x):
        g=x.pnl_usd[x.pnl_usd>0].sum(); l=-x.pnl_usd[x.pnl_usd<0].sum(); return round(g/l,2) if l>0 else np.nan
    for nm,sub in [('tous bras',pt),('baseline',pt[pt.arm=='baseline'])]:
        out=[]
        for lab,mask in [('tout',sub.s>-1e9),('top50',sub.s>=thr50),('top30',sub.s>=thr70),('bottom50',sub.s<thr50)]:
            x=sub[mask]; out.append(f"{lab}: n={len(x)} PF={pf(x)} WR={x.win.mean()*100:.0f}% PnL={x.pnl_usd.sum():+.0f}$ moy={x.net_pct.mean():+.1f}%")
        print('  ',nm,'|',' ; '.join(out))
# single best simple rule: momentum only
print('== momentum seul (neg) AUC train/test win:',round(roc_auc_score(tr.win,tr.neg_mom),3),round(roc_auc_score(te.win,te.neg_mom),3),'hit10:',round(roc_auc_score(tr.hit10,tr.neg_mom),3),round(roc_auc_score(te.hit10,te.neg_mom),3))
for lo,hi in [(-100,0),(0,15),(15,40),(40,1e9)]:
    for nm,d in [('train',tr),('test',te)]:
        x=d[(d.price_change_5m_at_entry>=lo)&(d.price_change_5m_at_entry<hi)]
        print(f'  mom5m [{lo},{hi}) {nm}: n={len(x)} WR={x.win.mean()*100:.0f}% hit10={x.hit10.mean()*100:.0f}% pnl={x.net_pct.mean():+.1f}%')
u.to_pickle('uniq3.pkl')

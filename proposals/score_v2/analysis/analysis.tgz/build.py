import json,glob,os,pandas as pd,numpy as np
rows=[]
files={'baseline':'data/trades_log.jsonl'}
for f in glob.glob('data/arms/*/trades_log.jsonl'): files[f.split('/')[2]]=f
for arm,f in files.items():
    for l in open(f):
        try:d=json.loads(l)
        except:continue
        d['arm']=arm; rows.append(d)
t=pd.DataFrame(rows)
t['te']=pd.to_datetime(t.timestamp_entry,utc=True,format='ISO8601'); t['tx']=pd.to_datetime(t.timestamp_exit,utc=True,format='ISO8601')
print(len(t), t['mode'].value_counts().to_dict())
g=t.sort_values('tx').groupby(['arm','position_id'])
first=g.first()
agg=pd.DataFrame({'pnl_usd':g.pnl_usd.sum(),'peak':g.peak_pct.max(),'trough':g.trough_pct.min(),
 'n_exits':g.size(),'last_reason':g.exit_reason.last(),'tx':g.tx.max(),'final':g.is_final_exit.max(),
 'exit_cost_first':g.exit_cost_pct.first(),'size_total':g.position_size.sum(),'frac0':g.fraction_of_initial.first()})
p=first[['token','token_address','te','entry_price','score_alpha','score_alpha_absolute','liquidity_at_entry','holders_at_entry','volume_1h_at_entry','rugcheck_score','age_hours_at_entry','price_change_5m_at_entry','params_version','stop_loss_trigger_pct']].join(agg).reset_index()
# initial size: size at first exit / fraction? inspect
print(t[['position_size','fraction_of_initial','pnl_pct','pnl_usd']].head(10))
p.to_pickle('pos.pkl'); print(len(p)); print(p.arm.value_counts()); print(p.te.min(),p.te.max())

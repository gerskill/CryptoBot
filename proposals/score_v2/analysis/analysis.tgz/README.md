Scripts d'analyse hors ligne (score v2, 2026-10-10). Exécutés sur une copie des journaux,
avec pandas/numpy/scikit-learn (venv séparé, rien installé dans le projet).
Ordre : build.py -> analyze.py -> model.py -> v2.py. Sortie complète : results.txt.
Entrées attendues dans ./data (copie de data/trades_log.jsonl, data/arms/*/trades_log.jsonl,
data/microstructure_log.jsonl) + economie.jsonl (lignes gate "economie" de data/funnel_log*.jsonl).

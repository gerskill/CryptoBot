import json,pandas as pd,numpy as np
from sklearn.metrics import roc_auc_score,brier_score_loss
p=pd.read_pickle('pos.pkl')
p=p[p.final==True].copy()
p['net_pct']=100*p.pnl_usd/p.size_total
p['hit10']=(p.peak>=10).astype(int); p['win']=(p.pnl_usd>0).astype(int)
# microstructure join
m=pd.DataFrame([json.loads(l) for l in open('data/microstructure_log.jsonl')])
m=m.dropna(subset=['position_id']).drop_duplicates(['arm','position_id'])
p=p.merge(m[['arm','position_id','round_trip_pct','depth_usd','impulse','price_drift_pct','liquidity_drift_pct','volume_over_liquidity']],on=['arm','position_id'],how='left')
p['vol_liq']=p.volume_1h_at_entry/p.liquidity_at_entry.clip(lower=1)
p['log_liq']=np.log10(p.liquidity_at_entry.clip(lower=1)); p['log_hold']=np.log10(p.holders_at_entry.clip(lower=1))
p['log_vol']=np.log10(p.volume_1h_at_entry.clip(lower=1)); p['log_age']=np.log10(p.age_hours_at_entry.clip(lower=0.01))
p['hour']=p.te.dt.hour; p['impulse']=p.impulse.astype(float)
p['liq_comp']=(100*p.log_liq/np.log10(150000)).clip(0,100)
p['ratio_comp']=(100*p.vol_liq/3).clip(0,100)
p['mom_comp']=(50+p.price_change_5m_at_entry).clip(0,100)
# clusters token+time (60 min)
p=p.sort_values('te')
cl=[];last={}
cid=0
for i,r in p.iterrows():
    k=r.token_address
    if k in last and (r.te-last[k][1]).total_seconds()<3600: cl.append(last[k][0])
    else: cid+=1; last[k]=(cid,r.te); cl.append(cid)
p['cluster']=cl
p.to_pickle('pos2.pkl')
u=p.groupby('cluster').first().reset_index()  # earliest position as representative
u['hit10_any']=p.groupby('cluster').hit10.max().values
u['net_mean']=p.groupby('cluster').net_pct.mean().values
u['win_mean']=(u.net_mean>0).astype(int)
u=u.sort_values('te').reset_index(drop=True)
n=len(u); cut=u.te.iloc[int(n*0.6)]
u['split']=np.where(u.te<cut,'train','test')
u.to_pickle('uniq.pkl')
print('positions finales',len(p),'clusters uniques',n,'cut',cut)
print(u.split.value_counts().to_dict(), 'hit10 rate', u.groupby('split').hit10.mean().round(3).to_dict(),'win rate',u.groupby('split').win.mean().round(3).to_dict())
feats=['score_alpha','score_alpha_absolute','liq_comp','ratio_comp','mom_comp','log_liq','log_hold','log_vol','vol_liq','rugcheck_score','log_age','price_change_5m_at_entry','round_trip_pct','depth_usd','impulse','price_drift_pct','liquidity_drift_pct','volume_over_liquidity','hour','exit_cost_first']
def auc(y,x):
    ok=~(pd.isna(x)|pd.isna(y))
    if ok.sum()<30 or y[ok].nunique()<2: return np.nan
    return roc_auc_score(y[ok],x[ok])
res=[]
for f in feats:
    tr=u[u.split=='train']; te=u[u.split=='test']
    row={'feat':f,'cov':round(u[f].notna().mean(),2)}
    for tgt in ['hit10','win']:
        row[f'{tgt}_tr']=auc(tr[tgt],tr[f]); row[f'{tgt}_te']=auc(te[tgt],te[f])
    # quintiles on whole
    q=pd.qcut(u[f].rank(method='first'),5,labels=False) if u[f].notna().sum()>50 else None
    if q is not None:
        g=u.groupby(q).agg(hit=('hit10','mean'),wr=('win','mean'),pnl=('net_pct','mean'),lo=(f,'min'),hi=(f,'max'),n=(f,'size'))
        row['quint']='; '.join(f"[{a.lo:.3g}-{a.hi:.3g}] hit{a.hit*100:.0f}% wr{a.wr*100:.0f}% pnl{a.pnl:+.1f}" for _,a in g.iterrows())
    res.append(row)
r=pd.DataFrame(res)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',300)
print(r[['feat','cov','hit10_tr','hit10_te','win_tr','win_te']].round(3).to_string())
for _,x in r.iterrows(): print(x.feat,'|',x.get('quint'))
